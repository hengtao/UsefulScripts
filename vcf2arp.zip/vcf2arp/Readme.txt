Usage:
python /Users/hengtao/Documents/GitHub/UsefulScripts/vcf2arp/vcf2arp.py -vcfile /Users/hengtao/Documents/GitHub/UsefulScripts/vcf2arp/example/ldfilter.rmDG001.vcf -groupfile /Users/hengtao/Documents/GitHub/UsefulScripts/vcf2arp/example/samples2pops.txt -arp /Users/hengtao/Documents/GitHub/UsefulScripts/vcf2arp/example/example.arp -header "An example of DNA sequence data"
